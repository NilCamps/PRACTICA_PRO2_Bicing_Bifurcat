#include "cjt_bicis.hh"
using namespace std;

cjt_bicis::cjt_bicis(){}
cjt_bicis::~cjt_bicis(){}
// 
bool cjt_bicis::existeix_b (string id_bici) const {
    map<string,bici> :: const_iterator it = bicis.find(id_bici);
    if (it != bicis.end()) return true;
    else return false;
}

//
void cjt_bicis::alta_bici(const string& id_bici, const string& id_est){
    map<string,bici>::iterator it = bicis.end();
    bici b;
    b.modificar_estacio_bici(id_est);
    bicis.insert(make_pair(id_bici,b));
}

//
void cjt_bicis::baixa_bici(string id_bici){
    map<string,bici>::iterator it = bicis.find(id_bici);
    bicis.erase(it);
}

//
void cjt_bicis::estacion_bici(string id_bici) const {
    map<string,bici>::const_iterator it = bicis.find(id_bici);
    cout << (*it).second.consultar_estacio() << endl;
}

//
void cjt_bicis::viajes_bici(string id_bici) const{
    map<string,bici>::const_iterator it = bicis.find(id_bici);
    (*it).second.viajes_bici();
}

//
void cjt_bicis::afegir_viatge(string id_est,string id_bici){
    map<string,bici>:: iterator it = bicis.find(id_bici);
    (*it).second.afegir_viatge(id_est);
}

//
string cjt_bicis::consultar_estacio(string id_bici) const {
    map<string,bici>::const_iterator it = bicis.find(id_bici);
    return (*it).second.consultar_estacio();
}
//
void cjt_bicis::modificar_estacio_bici (string id_bici, string id_est){
    map<string,bici>::iterator it = bicis.find(id_bici);
    (*it).second.modificar_estacio_bici(id_est);
}
