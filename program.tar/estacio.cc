#include "estacio.hh"
using namespace std;

estacio::estacio(){}
estacio::~estacio(){}

//
void estacio::alta_bici_est(string id_bici){
    bicis_est.insert(id_bici);
}

//
void estacio::baixa_bici_est(string id_bici){
    set<string> :: iterator it = bicis_est.find(id_bici);
    bicis_est.erase(it);
}

//
void estacio::bicis_estacion() const{
    set<string>::const_iterator it = bicis_est.begin();
    while (it != bicis_est.end()) {
        cout << *it << endl;
        ++it;
        }
}

//
int estacio::places_lliures_est() const{
    int places_lliures_estacio = capacitat - bicis_est.size();
    return places_lliures_estacio;
}

//
int estacio::places_ocupades_est() const{
    return bicis_est.size();
}

//
void estacio::modificar_capacitat(int cap){
    capacitat = cap;
}

//
void estacio::assignar_est(){}

int estacio::consultar_capacitat() const{
    return capacitat;
}

void estacio::inicialitzar(){
    cin >> capacitat;
}

string  estacio::consultar_bici() const{
    string primer = *(bicis_est.begin());
    return primer;
}