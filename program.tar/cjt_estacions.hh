/** @file cjt_estacions.hh
    @brief Especificación de la clase cjt_estacions
*/

#ifndef CJT_ESTACIONS_HH
#define CJT_ESTACIONS_HH

#include "BinTree.hh"
#include "estacio.hh"
#include "cjt_bicis.hh"
#include <iostream>
#include <map>

using namespace std;

/** @class cjt_estacions
    @brief Representa un conjunt de estacions que gestiona les estacions existents,
    les places lliures,les bicis de cada estacio i la capacitat de les estacions.
*/
class cjt_estacions {

    private:
    //ATRIBUTS:

        /** @brief conjunt de totes les estacions i els seus atributs, (id estació , atributs estació).*/
        map <string,estacio> estacions; 

        /** @brief Arbre de totes les estacions.*/
        BinTree <string> a_estacions;

        /** @brief Places lliures totals del conjunt d'estacions. Inicialitzada a 0.*/
        int pl_lliures = 0;

        /** @brief Operació de lectura. Inicialitza el cjt_estacions.
            \pre Al canal estàndard d'entrada es troben parells d'string i un enter > 0 que 
            representen l'identificador i la capacitat de les estacions que es volen afegir.
            Aqeustes estacions estan en preodre.
            \post S'inicialitza el map del paràmetre implícit i l'arbre a amb les estacions llegides.
            Les places totals passen a ser la suma de les capacitats de totes les estacions llegides.
        */
        void inicialitzar_rec(BinTree<string>& a);

        /** @brief Modificadora. Apropa bicis a la primera estació.
            \pre Les bicis contingudes a les estacions del paràmetre implícit existeixen al conjunt de bicis b.
                a_estacions no buit.
            \post Les bicis canvien d'estació segons els criteris de reestructuració de la pràctica.
        */
        void pujar_bicis_rec( const BinTree<string>& a, cjt_bicis& b);

        /** @brief Modificadora. Assigna una estació a una bici.
            \pre L'arbre a no és buit.
            \post Afeigeix una bici a la estació on és més necessari. 
            El criteri és assignar la estació amb major coeficient de desocupació.
            numero de places lliures de la estació + places lliures de les següents/num_estacions.
            En cas d'empat s'assigna la de id menor.
        */
        void assignar_est_rec(const BinTree<string>& a,int& places,int& num_est, double& max_coef,string& est_assignada); 
        
    public:
    //FUNCIONS:

        //CONSTRUCTORES:

        /** @brief Creadora por defecto.
            S'executa automaticament al declarar una estació.
            \pre <em>cert</em>
            \post El resultat es un conjunt d'estacions buit.
        */
        cjt_estacions();

        //DESTRUCTORES:

        /** @brief Destructora per defecte.
            \pre cert
            \post Esborra el cjt_estacions.
        */
        ~cjt_estacions();

        //CONSULTORES:

        /** @brief Consultora. Verifica l'existència d'una estació amb l'identificador especificat al mapa d'estacions.
            \pre id_est Un string que representa l'identificador de la estació a verificar.
            \post Comprova si hi ha una estació amb l'identificador donat en el mapa d'estacions
            de la instància actual de la classe cjt_estacions. Retorna true si l'estació amb
            l'identificador especificat existeix al mapa d'estacions,false en cas contrari.
         */
        bool existeix_e (string id_est) const;

        /** @brief Consultora. Busca l'identificador de l'estació i retorna el nombre de places lliures.
            \pre id_est Un string que representa l'identificador de la estació existent en el paràmetre implícit de la qual es vol consultar el nombre de places lliures.
            \post Busca l'estació amb l'identificador especificat al mapa de estacions de la
            instància actual de la classe cjt_estacions. Després, crida la funció `pl_lliures_est` de la classe
            estació corresponent a la estació trobada i retorna l'enter corresponent a les places lliures de l'estació desitjada.
        */
        int pl_lliures_est (string id_est) const;

        /** @brief Consultora. Retorna el nombre de places lliures que hi ha en total.
            \pre cert
            \post Retorna el nombre de places lliures totals de tot el cjt_estacions.
        */
        int pl_lliures_total () const;
        
       /** @brief Consultora. Consulta la capacitat de la estació.
            \pre id_est Un string que indica l'identificador de l'estació existent en el paràmetre implícit a la qual hem de modificar-ne la capacitat.
            \post Busca l'estació amb l'identificador especificat al mapa de estacions de la
            instància actual de la classe cjt_estacions. Després,retorna l'enter proporcionat per la funció `consultar_capacitat` de 
            la classe estació corresponent a la estació trobada.
        */
        int consultar_capacitat(string id_est) const;

        /** @brief Consultora. Consulta les places ocupades de la estació.
            \pre id_est Un string que indica l'identificador de l'estació existent en el paràmetre implícit a la qual hem de modificar-ne la capacitat.
            \post Busca l'estació amb l'identificador especificat al mapa de estacions de la
            instància actual de la classe cjt_estacions. Després, calcula les places ocupades mitjançant una resta entre les funcions 
            'consultar_capacitat' i 'places_lliures_est' de la classe estació corresponent a la estació trobada i 
            en retorna l'enter resultant.
        */
        int places_ocupades_est(string id_est) const;

        //MODIFICADORES:

        /** @brief Modificadora. Dona d'alta una nova bicicleta i l'assigna a una estació.
            \pre id_bici Un string que representa l'identificador únic de la nova bicicleta existent en el paràmetre implícit que no existeix.
            id_est Un string que indica l'identificador d'una estació existent no plena a la qual s'assignarà la bicicleta.
            \post Busca l'estació amb l'identificador especificat al mapa de estacions de la
            instància actual de la classe cjt_estacions. Després, crida la funció `alta_bici_est` de la classe
            estació corresponent a la estació trobada i se li passa l'id_bici que volem donar d'alta.
        */
        void alta_bici_est(string id_bici,string id_est);
        
        /** @brief Modificadora. Dona de baixa una bicicleta.
            \pre id_bici Un string que representa l'identificador únic d'una bicicleta existent en el paràmetre implícit.
            id_est Un string que indica l'identificador de l'estació a la qual esta assignada la bici.
            \post Busca l'estació amb l'identificador especificat al mapa de estacions de la
            instància actual de la classe cjt_estacions. Després, crida la funció `baixa_bici_est` de la classe
            estació corresponent a la estació trobada i se li passa l'id_bici que volem donar de baixa.
        */
        void baixa_bici_est(string id_bici, string id_est);

        /** @brief Modificadora. Modifica la capacitat de la estació.
            \pre id_est Un string que indica l'identificador de l'estació existent en el paràmetre implícit a la qual hem de modificar-ne la capacitat.
            cap Un enter que indica la nova capacitat de l'estació
            \post Busca l'estació amb l'identificador especificat al mapa de estacions de la
            instància actual de la classe cjt_estacions. Després, modifica les places lliures de l'estació i 
            crida la funció `modificar_capacitat` de la classe estació corresponent a la estació trobada i 
            se li passa l'enter cap que volem actualitzar.
        */
        void modificar_capacitat (string id_est, int cap);

        /** @brief Modificadora. Apropa bicis a la primera estació.
            \pre Les bicis contingudes a les estacions del paràmetre implícit existeixen al conjunt de bicis b.
                 El paràmetre implícit té com a mínim 1 estació.
            \post Les bicis canvien d'estació segons els criteris de reestructuració de la pràctica.
        */
        void pujar_bicis(cjt_bicis& b);

        /** @brief Modificadora. Assigna una estació a una bici.
            \pre Hi ha lloc per a una nova bici en alguna estació del paràmetre implícit.
            \post Afeigeix una bici a la estació on és més necessari. 
            El criteri és assignar la estació amb major coeficient de desocupació.
            numero de places lliures de la estació + places lliures de les següents/num_estacions.
            En cas d'empat s'assigna la de id menor.
        */
        string assignar_est();

        //LECTURA I ESCRITURA:

        /** @brief Operació de lectura. Inicialitza el cjt_estacions.
            \pre Al canal estàndard d'entrada es troben parells d'string i un enter > 0 que 
            representen l'identificador i la capacitat de les estacions que es volen afegir.
            Aqeustes estacions estan en preodre.
            \post S'inicialitza el paràmetre implícit amb les estacions llegides.
        */
        void inicialitzar();

        /** @brief Operació d'escritura. Escriu totes les bicis que estan assignades a una estació.
            \pre id_est Un string que indica l'identificador de l'estació de la qual volem saber les bicis assignades.
            \post Busca l'estació amb l'identificador especificat al mapa de estacions de la
            instància actual de la classe cjt_estacions. Després, crida la funció `bicis_estacion` de la classe
            estació corresponent a la estació trobada.
        */
        void escriure_bicis(string id_est) const;
        
};

#endif