/** @file estacio.hh
    @brief Especificación de la clase estacio
*/

#ifndef ESTACIO_HH
#define ESTACIO_HH

#include <iostream>
#include <set>

using namespace std;

/** @class estacio
    @brief Representa una estacio que gestiona la seva capacitat i ocupació i les bicis que conté.
*/
class estacio {
    private:
    //ATRIBUTS:

        /** @brief Capacitat de la estació.*/
        int capacitat;

        /** @brief Conjunt de bicis que hi ha a la estació.*/
        set <string> bicis_est;
    
    public:
    //FUNCIONS:

        //CONSTRUCTORES:

        /** @brief Constructora per defecte.
            S'executa automaticament al declarar una estació.
            \pre cert
            \post El resultat es una estació buida.
        */
        estacio();

        //DESTRUCTORES:

        /** @brief Destructora per defecte.
            \pre cert
            \post Esborra la estació.
        */
        ~estacio();

        //CONSULTORES:

        /** @brief Consultora. Retorna el nombre de places lliures de la estació
            \pre cert
            \post Retorna un enter que representa el nombre de places disponibles de la
            instància actual de la classe estacio.
        */
        int places_lliures_est() const;

        /** @brief Consultora. Retorna el nombre de places ocupades de la estació
            \pre cert
            \post Retorna un enter que representa el nombre de places no disponibles de la
            instància actual de la classe estacio.
        */
        int places_ocupades_est() const;

        /** @brief Consultora. Consulta la capacitat de la estació.
            \pre cert
            \post Retorna un enter que indica la capacitat actual de la estació.
                La informació proporcionada per aquesta funció pot ser utilitzada
                per als usuaris per conèixer el nombre de places màximes a ocupar.
        */
        int consultar_capacitat() const;

        /** @brief Consultora. Retorna la primera bici de la estació.
            \pre cert
            \post Retorna un string que indica ll'id de la primera bici del set bicis_est.
        */
        string consultar_bici() const;

        //MODIFICADORES:

        /** @brief Modificadora. Afegeix l'identificador d'una bicicleta al conjunt d'identificadors d'estació de la instància actual de la classe Bicicleta.
            \pre id_bici Un string que representa l'identificador d'una bicicleta no existent en el paràmetre implícit a afegir a l'estació existent en el paràmetre implícit.
            \post Afegeix l'identificador d'una bicicleta al set bicis_est que conté totes les bicis associades a una estació de la
            instància actual de la classe estacio. Aquest conjunt pot ser utilitzat per mantenir un registre de totes
            les bicicletes associades a una estació específica.
        */
        void alta_bici_est(string id_bici);
        
        /** @brief Modificadora. Elimina l'identificador d'una bicicleta del conjunt associat a l'estació de la instància actual de la classe estacio.
            \pre id_bici Un string que representa l'identificador de la bicicleta existent en el paàmetre implícit a eliminar del conjunt d'estació.
            \post Elimina l'identificador d'una bicicleta del set bicis_est associades a una estació de la
            instància actual de la classe estacio. 
        */
        void baixa_bici_est(string id_bici);

        /** @brief Modificadora. Modifica la capacitat actual de la estació.
            \pre cap Un enter que representa la nova capacitat de l'estació.
            \post Modifica la capacitat actual de la estació mitjançant
            l'assignació d'un nou enter cap.
        */
        void modificar_capacitat(int cap);

        /** @brief Modificadora. Retorna la primera bici de la estació.
            \pre cert
            \post Retorna un string que indica ll'id de la primera bici del set bicis_est.
        */
        void assignar_est ();

        //LECTURA I ESCRITURA:

        /** @brief Operació de lectura. Inicialitza el cjt_estacions.
            \pre cert
            \post Dona entrada a la capcitat de l'estació.
        */
        void inicialitzar();

        /** @brief Operació d'escriptura. Escriu a la sortida estàndard els identificadors de totes les bicicletes associades a l'estació de la instància actual de la classe Bicicleta.
            \pre cert
            \post Escriu a la sortida estàndard els identificadors de totes les bicicletes associades a una estació de la
            instància actual de la classe estacio.
        */
        void bicis_estacion() const;
};

#endif