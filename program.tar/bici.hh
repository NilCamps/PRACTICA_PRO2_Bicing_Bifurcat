/** @file bici.hh
    @brief Especificació de la clase bici
*/
#ifndef BICI_HH
#define BICI_HH
#include <iostream>
#include <map>
#include <list>

using namespace std;

/** @class bici
    @brief Representa una bici que gestiona els viatges que ha fet i la estació on es troba.
*/
class bici {

    private:
    //ATRIBUTS:
    
    /** @brief identificador de l'estació on es troba la bici.*/
    string id_est; 

    /** @brief llista de viatges (estació de sortida,estació destí). */
    list <pair<string,string>> viatges; 

    public:
    //FUNCIONS:

        //CONSTRUCTORES:

        /** @brief Constructora per defecte.
            S'executa automaticament al declarar una estació.
            \pre cert
            \post El resultat es una bici buida.
        */
        bici();

        //DESTRUCTORES:

        /** @brief Destructora per defecte.
            \pre cert
            \post Esborra la bici.
        */
        ~bici();

        //CONSULTORES:

        /** @brief Consultora. Consulta la estació on es troba la bicicleta.
            \pre cert
            \post Aquesta funció retorna un string que indica la estació actual on es troba
                la bicicleta. La informació proporcionada per aquesta funció pot ser utilitzada
                per als usuaris per conèixer la ubicació actual de la bicicleta.
        */
        string consultar_estacio() const;

        //MODIFICADORES:

        /** @brief Modificadora. Afegeix un viatge a una llista de parells de strings.
        \pre Un identificador d'establiment de destinació el qual existeix en el paràmetre implícit
        \post Afegeix el paràmetre id_est de la classe juntament amb el paràmetre implícit id_est_destí i els afeigeix  
            a una llista de parells de strings que representa els viatges.Cada parell
            consisteix en un identificador d'estació i un identificador d'estació de destinació.
        */
        void afegir_viatge(string id_est_desti);


        /** @brief Modificadora. Modifica la estació actual de la bicicleta.
            \pre nou_id_est Un string que representa el nou identificador de l'estació la qual existeix en el paràmetre implícit.
            \post Modifica l'estació actual de la bicicleta mitjançant
            l'assignació d'un nou identificador d'estació nou_id_est.
        */
        void modificar_estacio_bici (const string& nou_id_est);

        //LECTURA I ESCRIPTURA:

        /** @brief Operació d'escriptura. S'escriuen els viatges de la bici
            \pre: cert
            \post: S'escriu al canal estàndard de sortida l'estació origen i l'estació destí 
                de cadascun dels viatges realitzats per la bici del parametre implícit.
        */
        void viajes_bici() const;


};

#endif