/** @file program.cc
    @mainpage Practica_tardor_2023
    En aquest programa treballarem amb un sistema de Bicing Bifurcat. Introduïm les següents classes: cjt_estacions , estacio , cjt_bicis , bici .
*/

#include <iostream>
#include "cjt_estacions.hh"
#include "cjt_bicis.hh"
using namespace std;

/** @brief Tenim un sistema de Bicing. Composat per estacions i bicis.
    Es comença llegint la estructura de les estacions de bicing juntament amb la capacitat de cada una.Des d'aquest punt
    ja es pode realitzar una sèrie de accions que involucren estacions i bicis.
    Es pot donar d'alta una bici inexistent o donar de baixa una bici existent.
    Poden llistar-se les dades dels atributs de la bici i de les estacions.
    Es pot moure una bici d'una estació a una altra.
    Es poden llistar les bicis d'una estació per ordre d'identificador.
    Es poden fer modificacions dels atrbuts de les bicis i estacions.
    Es poden consultar atributs de les estacions i bicis.
*/
int main(){
    string op;
    cjt_estacions est;
    est.inicialitzar();
    cjt_bicis b;
    while (cin >> op and op != "fin"){

        string id_bici, id_est;

        if (op == "alta_bici" || op == "ab"){
            cin >> id_bici >> id_est;
            cout << "#ab " << id_bici << ' ' << id_est << endl;
            if(b.existeix_b(id_bici)) cout << "error: la bici ya existe" << endl;
            else if(!est.existeix_e(id_est)) cout << "error: la estacion no existe" << endl;
            else if (est.pl_lliures_est(id_est) == 0) cout << "error: la bici no cabe" << endl;
            else {
                b.alta_bici(id_bici,id_est);
                est.alta_bici_est(id_bici,id_est);
            }
        }

        else if (op == "baja_bici" || op == "bb"){
            cin >> id_bici;
            cout << "#bb " << id_bici << endl;
            if(!b.existeix_b(id_bici)) cout << "error: la bici no existe" << endl;
            else {
                string id_est = b.consultar_estacio(id_bici);
                b.baixa_bici(id_bici);
                est.baixa_bici_est(id_bici, id_est);
            }
        }

        else if (op == "estacion_bici" || op == "eb"){
            cin >> id_bici;
            cout << "#eb " << id_bici << endl;
            if(!b.existeix_b(id_bici)) cout << "error: la bici no existe" << endl;
            else{
                cout << b.consultar_estacio(id_bici) << endl;
            }
        }

        else if (op == "viajes_bici" || op == "vb"){
            cin >> id_bici;
            cout << "#vb " << id_bici << endl;
            if(!b.existeix_b(id_bici)) cout << "error: la bici no existe" << endl;
            else {
                b.viajes_bici(id_bici);
            }
        }

        else if (op == "mover_bici" || op == "mb"){
            cin >> id_bici >> id_est;
            cout << "#mb " << id_bici << ' ' << id_est << endl;
            if(!b.existeix_b(id_bici)) cout << "error: la bici no existe" << endl;
            else if(!est.existeix_e(id_est)) cout << "error: la estacion no existe" << endl;
            else if(id_est == b.consultar_estacio(id_bici)) cout << "error: la bici ya esta en el sitio" << endl;
            else if (est.pl_lliures_est(id_est) == 0) cout << "error: la bici no cabe" << endl;
            else{
                b.afegir_viatge(id_est,id_bici);
                est.baixa_bici_est(id_bici, b.consultar_estacio(id_bici));
                est.alta_bici_est(id_bici, id_est);
                b.modificar_estacio_bici(id_bici,id_est);
            }
        }

        else if (op == "bicis_estacion" || op == "be"){
            cin >> id_est;
            cout << "#be " << id_est << endl;
            if(!est.existeix_e(id_est)) cout << "error: la estacion no existe" << endl;
            else {
                est.escriure_bicis(id_est);
            }
        }
        
        else if (op == "modificar_capacidad" || op == "mc"){
            int cap;
            cin >> id_est >> cap;
            cout << "#mc " << id_est << " " << cap << endl;
            if(!est.existeix_e(id_est)) cout << "error: la estacion no existe" << endl;
            else if (est.places_ocupades_est(id_est) > cap) cout << "error: capacidad insuficiente" << endl;
            else{
                est.modificar_capacitat(id_est,cap);
            }
        }
        
        else if (op == "plazas_libres" || op == "pl"){
            cout << "#pl"<< endl;
            cout << est.pl_lliures_total() << endl;
        }
        
        else if (op == "subir_bicis" || op == "sb"){
            cout << "#sb" << endl;
            est.pujar_bicis(b);
        }
        
        else if (op == "asignar_estacion" || op == "ae"){
            cin >> id_bici;
            cout << "#ae " << id_bici << endl;
            if(b.existeix_b(id_bici)) cout << "error: la bici ya existe" << endl;
            else if(est.pl_lliures_total() == 0) cout << "error: no hay plazas libres" << endl;
            else{
                string id_est = est.assignar_est();
                est.alta_bici_est(id_bici, id_est);
                b.alta_bici(id_bici,id_est);
                cout << id_est << endl;
            }
        }
    }
}