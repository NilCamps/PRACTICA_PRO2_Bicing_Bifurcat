#include "cjt_estacions.hh"
using namespace std;


cjt_estacions::cjt_estacions(){}
cjt_estacions::~cjt_estacions(){}

//
bool cjt_estacions::existeix_e (string id_est) const{
    map <string,estacio> ::const_iterator it = estacions.find(id_est);
    if (it == estacions.end()) return false;
    else return true;
}

//
int cjt_estacions::pl_lliures_est (string id_est) const {
    map <string,estacio> :: const_iterator it = estacions.find(id_est);
    return (*it).second.places_lliures_est();
}

//
void cjt_estacions::alta_bici_est(string id_bici,string id_est){
    map<string,estacio>::iterator it = estacions.find(id_est);
    (*it).second.alta_bici_est(id_bici);
    --pl_lliures;
}

//
void cjt_estacions::baixa_bici_est(string id_bici, string id_est){
    map<string,estacio>::iterator it = estacions.find(id_est);
    (*it).second.baixa_bici_est(id_bici);
    ++pl_lliures;
}

//
void cjt_estacions::escriure_bicis(string id_est) const{
    map<string,estacio> :: const_iterator it = estacions.find(id_est);
    (*it).second.bicis_estacion();
}

//
void cjt_estacions::modificar_capacitat (string id_est, int cap){
    map<string,estacio>::iterator it = estacions.find(id_est);
    pl_lliures -= (*it).second.consultar_capacitat();
    pl_lliures += cap;
    (*it).second.modificar_capacitat(cap);
}

//
int cjt_estacions::pl_lliures_total() const{
    return pl_lliures;
}

//
void cjt_estacions::pujar_bicis(cjt_bicis& b){
    pujar_bicis_rec(a_estacions,b);
}

//
void cjt_estacions::pujar_bicis_rec( const BinTree<string>& a, cjt_bicis& b){
    if(not a.left().empty()){
            map<string, estacio>::iterator itv = estacions.find(a.value());
            map<string, estacio>::iterator itl = estacions.find(a.left().value());
            map<string, estacio>::iterator itr = estacions.find(a.right().value());
            int bicis = (*itv).second.places_lliures_est();
            while ((bicis > 0) and ((*itl).second.places_ocupades_est() > 0  or (*itr).second.places_ocupades_est() > 0)){
                string idb;
                if ((*itl).second.places_ocupades_est() > (*itr).second.places_ocupades_est()){
                    idb = (*itl).second.consultar_bici();
                    (*itl).second.baixa_bici_est(idb);
                }
                else if ((*itr).second.places_ocupades_est() > (*itl).second.places_ocupades_est()){
                    idb = (*itr).second.consultar_bici();           
                    (*itr).second.baixa_bici_est(idb);
                }
                else {
                    string idb_eq = (*itl).second.consultar_bici();
                    string idb_d = (*itr).second.consultar_bici();
                    
                    if ((idb_eq) < (idb_d)) {
                        idb = idb_eq;
                        (*itl).second.baixa_bici_est(idb);   
                    } 
                    else {
                        idb = idb_d;
                        (*itr).second.baixa_bici_est(idb);
                    } 
                }
                (*itv).second.alta_bici_est(idb);
                b.modificar_estacio_bici(idb,a.value());
                --bicis;
            }
            pujar_bicis_rec(a.left(),b);
            pujar_bicis_rec(a.right(),b);
        }
}

//
string cjt_estacions::assignar_est(){
    int places,num_est;
    double max_coef = -99;
    string est_assignada;
    assignar_est_rec(a_estacions,places,num_est,max_coef,est_assignada);
    
    return est_assignada;
}
void cjt_estacions::assignar_est_rec(const BinTree<string>& a,int& places,int& num_est, double& max_coef,string& est_assignada){

    if (!a.left().empty()){
        int pl_esq, pl_drt,num_est_esq,num_est_drt;
        assignar_est_rec(a.left(),pl_esq,num_est_esq,max_coef,est_assignada);
        assignar_est_rec(a.right(),pl_drt,num_est_drt,max_coef,est_assignada);
        map<string,estacio> :: const_iterator it = estacions.find(a.value());
        places = pl_esq + pl_drt + (*it).second.places_lliures_est();
        num_est = 1 + num_est_esq + num_est_drt;
    }

    else {
        num_est = 1;
        map<string,estacio> :: const_iterator it = estacions.find(a.value());
        places = (*it).second.places_lliures_est();
    }

    double coeficient = double(places)/double(num_est);

    if(max_coef == -99){
        max_coef = coeficient;
        est_assignada = a.value();
    }

    else if(coeficient > max_coef){
        max_coef = coeficient;
        est_assignada = a.value();
    }
    
    else if(coeficient == max_coef && a.value() < est_assignada){
        est_assignada = a.value();
    }
}


//
int cjt_estacions::consultar_capacitat(string id_est) const{
    map<string,estacio>::const_iterator it = estacions.find(id_est);
    return (*it).second.consultar_capacitat();
}

//
int cjt_estacions::places_ocupades_est(string id_est) const {
    map<string,estacio>::const_iterator it = estacions.find(id_est);
    int places_ocupades = (*it).second.consultar_capacitat() - (*it).second.places_lliures_est();
    return places_ocupades;
}

//
void cjt_estacions::inicialitzar(){
    inicialitzar_rec(a_estacions);
    
}
void cjt_estacions::inicialitzar_rec(BinTree<string>&a){
    string id_estacio;
    cin >> id_estacio;
    if(id_estacio != "#"){
        estacio est;
        est.inicialitzar();
        pl_lliures += est.consultar_capacitat();
        estacions.insert(make_pair(id_estacio,est));
        BinTree<string> e,d;
        inicialitzar_rec(e);
        inicialitzar_rec(d);
        a = BinTree<string> (id_estacio,e,d);
    }
    
}