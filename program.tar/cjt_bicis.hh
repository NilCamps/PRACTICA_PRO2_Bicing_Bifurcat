/** @file cjt_bicis.hh
    @brief Especificación de la clase cjt_bicics
*/
#ifndef CJT_BICI_HH
#define CJT_BICI_HH
#include <iostream>
#include <map>
#include "bici.hh"

using namespace std;

/** @class cjt_bicis
    @brief Representa un conjunt de bicis que gestiona les bicis que existeixen.
*/
class cjt_bicis{

    private:
    //ATRIBUTS:

     /** @brief conjunt de bicis (id de la bici, atributs de la bici)  */
    map<string,bici> bicis;

    public:
    //FUNCIONS:

        //CONSTRUCTORES:

        /** @brief Constructora per defecte.
            S'executa automaticament al declarar una estació.
            \pre cert
            \post El resultat es un conjunt d'estacions buit.
        */
        cjt_bicis();

        //DESTRUCTORES:

        /** @brief Destructora per defecte.
            S'executa automaticament al declarar una estació.
            \pre cert
            \post El resultat es un conjunt de bicis buit.
        */
        ~cjt_bicis();

        //CONSULTORES:

        /** @brief Consultora. Verifica l'existència d'una bicicleta amb l'identificador especificat al mapa de bicis.
            \pre id_bici Un string que representa l'identificador de la bicicleta a verificar.
            \post Comprova si hi ha una bicicleta amb l'identificador donat en el mapa de bicis
            de la instància actual de la classe cjt_bicis. Retorna true si la bicicleta amb
            l'identificador especificat existeix al mapa de bicicletes;false en cas contrari.
         */
        bool existeix_b (string id_bici) const;

        /** @brief Consultora. Busca l'identificador de l'estació associada a una bicicleta i l'escriu a la sortida estàndard.
            \pre id_bici Un string que representa l'identificador de la bicicleta de la qual es vol consultar l'estació.
            \post Busca la bicicleta amb l'identificador especificat al mapa de bicis de la
            instància actual de la classe cjt_bicis. Després, crida la funció `consultar_estacio` de la classe
            bici corresponent a la bicicleta trobada i retorna l'identificador de l'estació a la sortida estàndard.
        */
        string consultar_estacio(string id_bici) const;

        //MODIFICADORES:

        /** @brief Modificadora. Dona d'alta una nova bicicleta i l'assigna a una estació.
            \pre id_bici Un string que representa l'identificador únic de la nova bicicleta no existent.
            id_est Un string que indica l'identificador d'una estació existent a la qual s'assignarà la bicicleta.
            \post Afegeix una nova bicicleta amb l'identificador especificat al mapa
            de bicicletes de la instància actual de la classe cjt_bicis. La bicicleta és assignada
            a l'estació també especificada mitjançant l'identificador d'estació.
        */
        void alta_bici(const string& id_bici,const string& id_est);

        /** @brief Modificadora. Dóna de baixa una bicicleta identificada per l'identificador especificat.
            \pre id_bici Un string que representa l'identificador de la bicicleta existent a donar de baixa.
            \post Elimina del mapa de bicis de la instància actual de la classe cjt_bicis
            la bicicleta que té l'identificador especificat com a paràmetre.
        */
        void baixa_bici(string id_bici);

        /** @brief Modificadora. Afeigeix un viatge a la llita viatges.
            \pre Existeix ua bici amb id_bici, existeix una estació id_estació, la estació destí no coincideix amb la inicial.
            \post S'afegeix un viatge a la llista viatges.
        */
        void afegir_viatge(string id_est,string id_bici);

        /** @brief Modificadora. Modifica l'estació associada a una bicicleta mitjançant la crida a la funció de la classe Bicicleta.
            \pre id_bici Un string que representa l'identificador d'una  bicicleta existent en el paràmetre implícit de la qual es vol modificar l'estació.
            id_est Un string que representa el nou identificador de l'estació existent en el paràmetre implícit a assignar a la bicicleta.
            \post Busca la bicicleta amb l'identificador especificat al mapa de bicis de la
            instància actual de la classe cjt_bicis. Després, crida la funció `modificar_est` de la classe
            bici corresponent a la bicicleta trobada per modificar l'estació associada.
        */
        void modificar_estacio_bici (string id_bici, string id_est);

        //LECTURA I ESCRIPTURA:

        /** @brief Operació d'escriptura. Busca l'identificador de l'estació associada a una bicicleta i l'escriu a la sortida estàndard.
            \pre id_bici Un string que representa l'identificador de la bicicleta existent en el paràmetre implícit de la qual es vol consultar l'estació.
            \post Busca la bicicleta amb l'identificador especificat al mapa de bicis de la
            instància actual de la classe cjt_bicis. Després, crida la funció `consultar_estacio` de la classe
            bici corresponent a la bicicleta trobada i escriu l'identificador de l'estació a la sortida estàndard.
        */
        void estacion_bici(string id_bici) const;

        /** @brief Operació d'escriptura. Busca l'identificador de l'estació associada a una bicicleta i l'escriu a la sortida estàndard.
            \pre id_bici Un string que representa l'identificador de la bicicleta existent en el paràmetre implícit de la qual es vol consultar l'estació.
            \post Busca la bicicleta amb l'identificador especificat al mapa de bicis de la
            instància actual de la classe cjt_bicis. Després, crida la funció `viatges_bici` de la classe
            bici corresponent a la bicicleta trobada.
        */
        void viajes_bici(string id_bici) const;

};

#endif