#include "bici.hh"
using namespace std;

bici::bici(){}
bici::~bici(){}

//
void bici::viajes_bici() const{
    list <pair<string,string>>::const_iterator it = viatges.begin();
    while(it != viatges.end()){
        cout <<  (*it).first << ' ' << (*it).second << endl;
        ++it;
    }
}

//
void bici::afegir_viatge(string id_est_desti){
    string sortida = id_est;
    string arribada = id_est_desti;
    viatges.insert(viatges.end(), make_pair(sortida,arribada));
}

//
string bici::consultar_estacio() const{
    return id_est;
}

//
void bici::modificar_estacio_bici (const string& nou_id_est){
    id_est = nou_id_est;
}